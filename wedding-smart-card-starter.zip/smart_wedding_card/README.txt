# Wedding Smart Card

## Files
- `index.html` — complete editable wedding invitation website
- `assets/curtain-opening.mp4` — supplied curtain-opening video
- `assets/cream-gold-background.jpg` — supplied repeating cream/gold background
- `assets/royal-frame-reference.png` — supplied frame reference image

## Publish with GitHub Pages
1. Extract this ZIP.
2. Upload `index.html` and the complete `assets` folder into the root of your GitHub repository.
3. In GitHub, open Settings → Pages and enable deployment from your main branch/root folder.
4. Open the published Pages link.

## Customize
Open `index.html` and find `const CARD = {` near the bottom.
Change the names, parents' names, wedding date/time, venue, address, music file and design link.
Update the Haldi/Sangeet/Sagai/Vidai event-card text directly in the HTML.

The curtain video plays once. When it ends, the page captures its final frame and fades in the HTML text. The cream-and-gold paper background repeats vertically; the closing section is maroon.
